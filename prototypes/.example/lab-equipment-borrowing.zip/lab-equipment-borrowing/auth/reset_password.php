<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reset Password — Lab Equipment Borrowing System</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

  <header class="site-header">
    <div class="brand">
      <span class="logo-dot"></span>
      <h2>Lab Equipment Borrowing System</h2>
    </div>
    <nav>
      <a href="login.php">Borrower Login</a>
      <a href="admin_login.php">Admin Login</a>
    </nav>
  </header>

  <div class="auth-wrapper">
    <div class="auth-card">
      <div class="auth-icon">&#128273;</div>
      <h1>Reset Your Password</h1>
      <p class="auth-subtitle">Choose a new password for your account</p>

      <!-- Static demo: error state (sample only) -->
      <div class="alert alert-error">
        <span>&#9888;</span>
        <div>This reset link has expired. Please request a new one.</div>
      </div>

      <form class="styled-form" action="reset_password.php" method="POST">

        <label for="new_password">New Password</label>
        <input type="password" id="new_password" name="new_password" placeholder="Enter new password">
        <p class="field-hint">Minimum 8 characters, with at least one number.</p>

        <label for="confirm_password">Confirm New Password</label>
        <input type="password" id="confirm_password" name="confirm_password" placeholder="Re-enter new password">

        <button type="submit" class="btn btn-block">Update Password</button>
      </form>

      <p class="auth-footer-link">
        Changed your mind? <a href="login.php">Back to Login</a>
      </p>
    </div>
  </div>

  <footer class="site-footer">
    <p>&copy; Lab Equipment Borrowing System</p>
  </footer>

  <script src="../assets/js/script.js"></script>
</body>
</html>
