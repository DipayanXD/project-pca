<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard — Lab Equipment Borrowing System</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

  <header class="site-header">
    <h2>Lab Equipment Borrowing System</h2>
    <nav>
      <a href="catalog.php">Equipment Catalog</a>
      <a href="my_requests.php">My Requests</a>
      <a href="profile.php">Profile</a>
      <a href="../auth/logout.php">Logout</a>
    </nav>
  </header>

  <main class="page-content">
    <h1>Borrower Dashboard</h1>
    <p class="page-note">Landing page after borrower login — summary of own requests and quick links.</p>

    <!-- TODO: PHP logic goes here (to be added in class) -->

  </main>

  <footer class="site-footer">
    <p>&copy; Lab Equipment Borrowing System</p>
  </footer>

  <script src="../assets/js/script.js"></script>
</body>
</html>
